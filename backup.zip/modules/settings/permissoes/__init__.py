# Permissions Manager Module Initialization
